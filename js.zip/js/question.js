const Questions = [
    {
        question: '...... you interested in sport?',
        answers: [
            {
                answer: 'Be',
                correct: false
            },
            {
                answer: 'Am',
                correct: false
            },
            {
                answer: 'Is',
                correct: false
            },
            {
                answer: 'Are',
                correct: true
            }

        ],
    },
    {
        question: 'My ...... is a writer and his books are very popular.',
        answers: [
            {
                answer: 'aunt',
                correct: false
            },
            {
                answer: 'uncle',
                correct: true
            },
            {
                answer: 'sister',
                correct: false
            },
            {
                answer: 'mother',
                correct: false
            }

        ]
    },
    {
        question: 'Paul is very....... He’s very good at art.',
        answers: [
            {
                answer: 'honest',
                correct:false
            },
            {
                answer: 'friendly',
                correct:false
            },
            {
                answer: 'polite',
                correct:false
            },
            {
                answer: 'creative',
                correct:true
            }
        ]
    }
];




    let ad1 = [{
    question: 'We live in the city centre and our house.... have a big garden.',
    answers: [
        {
            answer: 'doesn&rsquo;t',
            correct: true
        },
        {
            answer: 'isn&rsquo;t',
            correct: false
        },
        {
            answer: 'aren&rsquo;t',
            correct: false
        },
        {
            answer: 'don&rsquo;t',
            correct: false
        }

    ]

}];

Questions.push(ad1[0])



          let ad2 = [{

        question: 'I .... arrive at school before nine o’clock.',
    answers: [
    {
        answer: 'has to',
        correct: false
    },
    {
        answer: 'have to',
        correct: true
    },
    {
        answer: 'doesn&rsquo;t have to',
        correct: false
    },
    {
        answer: 'haven&rsquo;t to',
        correct: false
    }

    ]

    }];

    Questions.push(ad2[0])
        
          let ad3 = [{
        question: 'The beach was very crowded  ......Monday.',
    answers: [
    {
        answer: 'in',
        correct: false
    },
    {
        answer: 'on',
        correct: true
    },
    {
        answer: 'at',
        correct: false
    },
    {
        answer: 'to',
        correct: false
    }

    ]

    }];
    Questions.push(ad3[0])
        
          let ad4 = [{
        question: 'You ..... eat all that cake! It isn’t good for you',
    answers: [
    {
        answer: 'don&rsquo;t',
        correct: false
    },
    {
        answer: 'may not',
        correct: false
    },
    {
        answer: 'shouldn&rsquo;t',
        correct: true
    },
    {
        answer: 'will not',
        correct: false
    }

    ]

    }];
    Questions.push(ad4[0])
        
          let ad5 = [{
        question: 'Cathy......a game on her computer at the moment.',
    answers: [
    {
        answer: 'plays',
        correct: false
    },
    {
        answer: ' is playing',
        correct: true
    },
    {
        answer: 'to play',
        correct: false
    },
    {
        answer: ' play',
        correct: false
    }

    ]

    }];
    Questions.push(ad5[0])
        
          let ad6 = [{
        question: 'There ...... a lot of people outside the school.What’s the problem?',
    answers: [
    {
        answer: 'are',
        correct: true
    },
    {
        answer: 'is',
        correct: false
    },
    {
        answer: 'be',
        correct: false
    },
    {
        answer: 'am',
        correct: false
    }

    ]

    }];
    Questions.push(ad6[0])
        
          let ad7 = [{
        question: '......... you like to come out with us tonight?',
    answers: [
    {
        answer: 'Do',
        correct: false
    },
    {
        answer: 'Would',
        correct: true
    },
    {
        answer: 'Are',
        correct: false
    },
    {
        answer: 'Will',
        correct: false
    }

    ]

    }];
    Questions.push(ad7[0])
        
          let ad8 = [{
        question: 'How ...... time have we got to do this exercise?',
    answers: [
    {
        answer: 'long',
        correct: false
    },
    {
        answer: 'many',
        correct: false
    },
    {
        answer: 'much',
        correct: true
    },
    {
        answer: 'quick',
        correct: false
    }

    ]

    }];
    Questions.push(ad8[0])
        
          let ad9 = [{
        question: 'Turn ...... and you’ll see the museum on the left.',
    answers: [
    {
        answer: 'on the right',
        correct: false
    },
    {
        answer: 'rightly',
        correct: false
    },
    {
        answer: 'by the right',
        correct: false
    },
    {
        answer: 'right',
        correct: true
    }

    ]

    }];
    Questions.push(ad9[0])
        
          let ad10 = [{
        question: 'Don’t forget to get .... the bus at Station Road.',
    answers: [
    {
        answer: 'out',
        correct: false
    },
    {
        answer: 'off',
        correct: true
    },
    {
        answer: 'over',
        correct: false
    },
    {
        answer: 'down',
        correct: false
    }

    ]

    }];
    Questions.push(ad10[0])
        
          let ad11 = [{
        question: 'Tom got the ...... marks in the class for his homework.',
    answers: [
    {
        answer: 'worse',
        correct: false
    },
    {
        answer: 'worst',
        correct: true
    },
    {
        answer: 'baddest',
        correct: false
    },
    {
        answer: 'most bad',
        correct: false
    }

    ]

    }];
    Questions.push(ad11[0])
        
          let ad12 = [{
        question: 'There wasn’t .... milk for breakfast this morning so I had toast and orange juice.',
    answers: [
    {
        answer: 'a',
        correct: false
    },
    {
        answer: 'some',
        correct: false
    },
    {
        answer: 'the',
        correct: false
    },
    {
        answer: 'any',
        correct: true
    }

    ]

    }];
    Questions.push(ad12[0])
        
          let ad13 = [{
        question: 'My sister ...... speak French when she was only six years old.',
    answers: [
    {
        answer: 'was',
        correct: false
    },
    {
        answer: 'should',
        correct: false
    },
    {
        answer: 'could',
        correct: true
    },
    {
        answer: 'had',
        correct: false
    }

    ]

    }];
    Questions.push(ad13[0])
        
          let ad14 = [{
        question: 'Did you ....... shopping after school yesterday?',
    answers: [
    {
        answer: 'went',
        correct: false
    },
    {
        answer: 'goed',
        correct: false
    },
    {
        answer: 'going',
        correct: false
    },
    {
        answer: 'go',
        correct: true
    }

    ]

    }];
    Questions.push(ad14[0])
        
          let ad15 = [{
        question: 'I ...... five emails before school today.',
    answers: [
    {
        answer: 'sent',
        correct: true
    },
    {
        answer: 'sended',
        correct: false
    },
    {
        answer: 'did send',
        correct: false
    },
    {
        answer: 'was send',
        correct: false
    }

    ]

    }];
    Questions.push(ad15[0])
        
          let ad16 = [{
        question: 'Question Our teacher speaks English to us ...... so that we can understand her.',
    answers: [
    {
        answer: 'slow',
        correct: false
    },
    {
        answer: 'slower',
        correct: false
    },
    {
        answer: 'more slow',
        correct: false
    },
    {
        answer: 'slowly',
        correct: true
    }

    ]

    }];
    Questions.push(ad16[0])
        
          let ad17 = [{
        question: 'Quick – get the food inside! It ....... any moment.',
    answers: [
    {
        answer: 'rains',
        correct: false
    },
    {
        answer: 'is raining',
        correct: false
    },
    {
        answer: 'is going to rain',
        correct: true
    },
    {
        answer: 'can rain',
        correct: false
    }

    ]

    }];
    Questions.push(ad17[0])
        
          let ad18 = [{
        question: 'I ...... the new Batman film yet. Is it any good?',
    answers: [
    {
        answer: 'haven&rsquo;t seen',
        correct: true
    },
    {
        answer: 'didn&rsquo;t see',
        correct: false
    },
    {
        answer: 'don&rsquo;t see ',
        correct: false
    },
    {
        answer: 'am not seen',
        correct: false
    }

    ]

    }];
    Questions.push(ad18[0])
        
          let ad19 = [{
        question: 'I hope you ....... a good time at the moment in Greece! Phone soon.',
    answers: [
    {
        answer: 'are having',
        correct: true
    },
    {
        answer: 'have',
        correct: false
    },
    {
        answer: 'have had',
        correct: false
    },
    {
        answer: 'had',
        correct: false
    }

    ]

    }];
    Questions.push(ad19[0])
        
          let ad20 = [{
        question: 'I wanted to see Harry. How long ago ......?',
    answers: [
    {
        answer: 'he left',
        correct: false
    },
    {
        answer: 'has he left',
        correct: false
    },
    {
        answer: 'did he leave',
        correct: true
    },
    {
        answer: 'could he leave',
        correct: false
    }

    ]

    }];
    Questions.push(ad20[0])
        
          let ad21 = [{
        question: 'Do students in your country have to stand ... when the teacher arrives?',
    answers: [
    {
        answer: 'on',
        correct: false
    },
    {
        answer: 'at',
        correct: false
    },
    {
        answer: 'in',
        correct: false
    },
    {
        answer: 'up',
        correct: true
    }

    ]

    }];
    Questions.push(ad21[0])
        
          let ad22 = [{
        question: ' Which train ............  for when I saw you on the platform on Sunday?',
    answers: [
    {
        answer: 'did you wait',
        correct: false
    },
    {
        answer: 'were you waiting',
        correct: true
    },
    {
        answer: 'have you waited',
        correct: false
    },
    {
        answer: 'are you waiting',
        correct: false
    }

    ]

    }];
    Questions.push(ad22[0])
        
          let ad23 = [{
        question: 'You ....  hurry as we’ve still got twenty minutes before the film starts.',
    answers: [
    {
        answer: 'mustn&rsquo;t',
        correct: false
    },
    {
        answer: 'can&rsquo;t',
        correct: false
    },
    {
        answer: 'may not',
        correct: false
    },
    {
        answer: 'needn&rsquo;t',
        correct: true
    }

    ]

    }];
    Questions.push(ad23[0])
        
          let ad24 = [{
        question: ' That car is ...... dangerous to drive.',
    answers: [
    {
        answer: 'too',
        correct: true
    },
    {
        answer: 'enough',
        correct: false
    },
    {
        answer: 'not enough',
        correct: false
    },
    {
        answer: 'the worst',
        correct: false
    }

    ]

    }];
    Questions.push(ad24[0])
        
          let ad25 = [{
        question: 'I ...... you in the café at about 4.30 and we can discuss our plans then, OK?',
    answers: [
    {
        answer: '&rsquo;ll see',
        correct: true
    },
    {
        answer: 'am going to see',
        correct: false
    },
    {
        answer: 'am seeing',
        correct: false
    },
    {
        answer: 'see',
        correct: false
    }

    ]

    }];
    Questions.push(ad25[0])



          let ad26 = [{
        question: 'My father has been a pilot ... twenty years and he still loves his job.',
    answers: [
    {
        answer: 'since',
        correct: false
    },
    {
        answer: 'for',
        correct: true
    },
    {
        answer: 'until',
        correct: false
    },
    {
        answer: 'by',
        correct: false
    }

    ]

    }];

    Questions.push(ad26[0])


          let ad27 = [{
        question: "I really enjoy .... new languages and I’d like to learn Italian soon.",
    answers: [
    {
        answer: 'to learn',
        correct: false
    },
    {
        answer: 'learning',
        correct: true
    },
    {
        answer: 'learn',
        correct: false
    },
    {
        answer: 'learned',
        correct: false
    }

    ]

    }];
    Questions.push(ad27[0])
        
          let ad28 = [{
        question: 'If we ...... in the countryside, we’d have much better views than we do now.',
    answers: [
    {
        answer: 'lived',
        correct: true
    },
    {
        answer: 'were live',
        correct: false
    },
    {
        answer: 'would live',
        correct: false
    },
    {
        answer: 'live',
        correct: false
    }

    ]

    }];
    Questions.push(ad28[0])
        
          let ad29 = [{
        question: 'I wish Joe ..........  to Hawaii on holiday. They’re talking about an eruption there on the news.',
    answers: [
    {
        answer: 'doesn&rsquo;t go',
        correct: false
    },
    {
        answer: 'didn&rsquo;t go',
        correct: false
    },
    {
        answer: 'hasn&rsquo;t gone',
        correct: false
    },
    {
        answer: 'hadn&rsquo;t gone',
        correct: true
    }

    ]

    }];
    Questions.push(ad29[0])
        
          let ad30 = [{
        question: 'Could I possibly ......... some money for the bus fare home? I’ve lost my bag.',
    answers: [
    {
        answer: 'lend',
        correct: false
    },
    {
        answer: 'owe',
        correct: false
    },
    {
        answer: 'borrow',
        correct: true
    },
    {
        answer: 'need',
        correct: false
    }

    ]

    }];
    Questions.push(ad30[0])
        
          let ad31 = [{
        question: 'Sam asked me if I ...... a lift home after the concert.',
    answers: [
    {
        answer: ' had wanted ',
        correct: false
    },
    {
        answer: 'wanted',
        correct: true
    },
    {
        answer: 'would want',
        correct: false
    },
    {
        answer: 'want',
        correct: false
    }

    ]

    }];
    Questions.push(ad31[0])
        
          let ad32 = [{
        question: 'People say that an avalanche ......	 by loud noises in the area but I don’t know if that’s true.',
    answers: [
    {
        answer: 'causes',
        correct: false
    },
    {
        answer: 'has caused',
        correct: false
    },
    {
        answer: 'is causing',
        correct: false
    },
    {
        answer: 'is caused',
        correct: true
    }

    ]

    }];
    Questions.push(ad32[0])
        
          let ad33 = [{
        question: 'Look at the news! Three cars  ...... in a bad accident on the motorway at Dartford.',
    answers: [
    {
        answer: 'are involving',
        correct: false
    },
    {
        answer: 'involve',
        correct: false
    },
    {
        answer: 'have involved ',
        correct: false
    },
    {
        answer: 'have been involved',
        correct: true
    }

    ]

    }];
    Questions.push(ad33[0])
        
          let ad34 = [{
        question: 'I ...... for arriving so late but I was caught up in a traffic jam in the town centre.',
    answers: [
    {
        answer: 'sorry',
        correct: false
    },
    {
        answer: 'regret',
        correct: false
    },
    {
        answer: 'apologise',
        correct: true
    },
    {
        answer: 'afraid',
        correct: false
    }

    ]

    }];
    Questions.push(ad34[0])

        
          let ad35 = [{
        question: ' Look out for a petrol station because I think we’re going to run ...... of petrol soon.',
    answers: [
    {
        answer: 'down',
        correct: false
    },
    {
        answer: 'out',
        correct: true
    },
    {
        answer: 'off',
        correct: false
    },
    {
        answer: 'through',
        correct: false
    }

    ]

    }];
    Questions.push(ad35[0])
        
          let ad36 = [{
        question: ' It was great to see you at the party. I didn’t realize how long ...... since we last met.',
    answers: [
    {
        answer: 'it had been',
        correct: true
    },
    {
        answer: 'it was been',
        correct: false
    },
    {
        answer: 'it was being',
        correct: false
    },
    {
        answer: 'it is been',
        correct: false
    }

    ]

    }];
    Questions.push(ad36[0])
        
          let ad37 = [{
        question: 'The girls .... to each other since the film started.',
    answers: [
    {
        answer: 'talked',
        correct: false
    },
    {
        answer: 'were talking',
        correct: false
    },
    {
        answer: 'are talking',
        correct: false
    },
    {
        answer: 'have been talking',
        correct: true
    }

    ]

    }];
    Questions.push(ad37[0])
        
          let ad38 = [{
        question: 'By the time I hand in this project, I ...... on it for three weeks! ',
    answers: [
    {
        answer: '&rsquo;ll be working ',
        correct: false
    },
    {
        answer: '&rsquo;ll have been working',
        correct: true
    },
    {
        answer: 'have worked ',
        correct: false
    },
    {
        answer: '&rsquo;ll work',
        correct: false
    }

    ]

    }];
    Questions.push(ad38[0])
        
          let ad39 = [{
        question: 'Jonah’s just fallen down the steps outside and there’s ...... everywhere.',
    answers: [
    {
        answer: 'bone',
        correct: false
    },
    {
        answer: 'blood',
        correct: true
    },
    {
        answer: 'skin',
        correct: false
    },
    {
        answer: 'cut',
        correct: false
    }

    ]

    }];
    Questions.push(ad39[0])
        
          let ad40 = [{
        question: ' I really wish people ...... dump litter in front of our house. We have to clear it up every day.',
    answers: [
    {
        answer: 'won&rsquo;t',
        correct: false
    },
    {
        answer: 'wouldn&rsquo;t',
        correct: true
    },
    {
        answer: 'haven&rsquo;t',
        correct: false
    },
    {
        answer: 'don&rsquo;t',
        correct: false
    }

    ]

    }];
    Questions.push(ad40[0])
        
          let ad41 = [{
        question: ' You should be very proud ...... what you’ve achieved over the last year.',
    answers: [
    {
        answer: 'of',
        correct: true
    },
    {
        answer: 'on',
        correct: false
    },
    {
        answer: 'to',
        correct: false
    },
    {
        answer: 'for',
        correct: false
    }

    ]

    }];
    Questions.push(ad41[0])
        
          let ad42 = [{
        question: ' ...... people know this but our school is being inspected today.',
    answers: [
    {
        answer: 'Little',
        correct: false
    },
    {
        answer: 'Any',
        correct: false
    },
    {
        answer: 'None',
        correct: false
    },
    {
        answer: 'Few',
        correct: true
    }

    ]

    }];
    Questions.push(ad42[0])
        
          let ad43 = [{
        question: 'That’s the office ...... my dad works.',
    answers: [
    {
        answer: 'who',
        correct: false
    },
    {
        answer: 'where',
        correct: true
    },
    {
        answer: 'that',
        correct: false
    },
    {
        answer: 'which',
        correct: false
    }

    ]

    }];
    Questions.push(ad43[0])
        
          let ad44 = [{
        question: 'The studio lights went out while the footballer .......... . ',
    answers: [
    {
        answer: 'had been interviewed',
        correct: false
    },
    {
        answer: ' was interviewed',
        correct: false
    },
    {
        answer: 'was being interviewed',
        correct: true
    },
    {
        answer: 'was interviewing',
        correct: false
    }

    ]

    }];
    Questions.push(ad44[0])
        
          let ad45 = [{
        question: 'Last Tuesday the company told Ruth that they’d emailed her the job details the ...... day.',
    answers: [
    {
        answer: 'last',
        correct: false
    },
    {
        answer: 'before',
        correct: false
    },
    {
        answer: 'previous',
        correct: true
    },
    {
        answer: 'earlier',
        correct: false
    }

    ]

    }];
    Questions.push(ad45[0])
        
          let ad46 = [{
        question: 'I must remember ..... Ed to take notes for me while I’m away next week.',
    answers: [
    {
        answer: 'ask',
        correct: false
    },
    {
        answer: 'to ask',
        correct: true
    },
    {
        answer: 'asking',
        correct: false
    },
    {
        answer: 'for asking',
        correct: false
    }

    ]

    }];
    Questions.push(ad46[0])
        
          let ad47 = [{
        question: 'If I’d gone to the sales yesterday, I ...... one of those cheap bags before they sold out.',
    answers: [
    {
        answer: 'could have bought',
        correct: true
    },
    {
        answer: 'had bought',
        correct: false
    },
    {
        answer: 'would buy',
        correct: false
    },
    {
        answer: 'bought',
        correct: false
    }

    ]

    }];
    Questions.push(ad47[0])
        